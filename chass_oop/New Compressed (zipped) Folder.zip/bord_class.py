import picec_class as pi
lost_soldierList = []


class BOARD:

    def __init__(self):
        self._bord = [[pi.Rook(), pi.KNIGHT(), pi.Bishop(), pi.Queen(), pi.King(), pi.Bishop(), pi.KNIGHT(), pi.Rook()],
                      [pi.Sioldier(), pi.Sioldier(), pi.Sioldier(), pi.Sioldier(), pi.Sioldier(), pi.Sioldier(), pi.Sioldier(), pi.Sioldier()],
                      [0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0],
                      [pi.BlackSoldier("b"), pi.BlackSoldier("b"), pi.BlackSoldier("b"), pi.BlackSoldier("b"), pi.BlackSoldier("b"), pi.BlackSoldier("b"), pi.BlackSoldier("b"), pi.BlackSoldier("b")],
                      [pi.Rook("b", "\u265C"), pi.KNIGHT("b"), pi.Bishop("b"), pi.Queen("b"), pi.King("b"), pi.Bishop("b"), pi.KNIGHT("b"), pi.Rook("b")]]
        self.lost_soldierList = []
        self.list_bord = []

    def get_color(self, x, y):
        if self._bord[x][y] != 0:
            return self._bord[x][y].color
        else:
            return 0

    def get_position(self, x, y):
        print(x, y)
        return self._bord[x][y]

    def eat_piece(self, x, y):
        piece_to_eat = self.get_position(x, y).kinde
        # print(piece_to_eat,88)
        # piece_to_eat = self.get_position(x, y).kinde, 1)
        self.lost_soldierList.append(piece_to_eat)
        # self.lost_soldierList = self.lost_soldierList.append(self.get_position(x, y))

        print(self.lost_soldierList, 11)

    def change_positione(self, oldx, oldy, newx, newy):
        self._bord[newx][newy] = self._bord[oldx][oldy]
        self._bord[oldx][oldy] = 0

    def chess_bord_print(self):
        self.list_bord = []
        for i in range(8):
            self.list_bord = []
            print("")
            for x in range(8):
                if self._bord[i][x] != 0:
                    uni = self._bord[i][x].get_unie()
                    self.list_bord.append(uni)
                else:
                    self.list_bord.append("_")
            for p in range(len(self.list_bord)):
                print(self.list_bord[p], end=" ")
    print("")

    def white_black_space(self, x, y):
        return self._bord[x][y].color

    def movment_on_the_bord(self, oldx, oldy, newx, newy):
        oldy = int(oldy)
        # allow_ro_not_to_move = chess_bord._bord[oldx][oldy].movment(oldx, oldy, newx, newy)
        print(333)
        courent_soldier = self.get_position(oldx, oldy)

        # courent_soldier = self._bord[oldx][oldy]
        allow_ro_not_to_move = courent_soldier.movment(oldx, oldy, newx, newy)
        if allow_ro_not_to_move:
            print(9)
            if self._bord[newx][newy] != 0:
                # print(self._bord[newx][newy], 1)
                if self._bord[newx][newy].color != self.get_color(oldx, oldy):
                    self.eat_piece(newx, newy)
                    # lost_soldierList.append(self._bord[newx][newy].kinde)
                    # print(lost_soldierList, 5555555)
                    # print(self._bord)
            self.change_positione(oldx, oldy, newx, newy)
            # self._bord[newx][newy] = self._bord[oldx][oldy]
            # self._bord[oldx][oldy] = 0
            self.chess_bord_print()
            return True
        else:
            print(21)
            return False
            # if  self.whiteCounter > self.blackCounter:
            #     self.whiteCounter -= 1
            # else:
            #     print('the move is not valid!')
            #     self.blackCounter -= 1
            # self.player_tourn()

    def check_valid(self, cord):

        cord1 = cord[0]
        cord2 = cord[1]
        cord3 = cord[2]
        if len(cord) == 3 and (len(cord1) == 1) and (len(cord3) == 1) and cord2 == ",":
            if cord1.isnumeric() and cord3.isnumeric() and (-1 < int(cord1) < 8) and (-1 < int(cord3) < 8):
                return True
            else:
                print(" not leigale char")
                return False
        else:
            print(" not leigale char")
            return False


# def destin_Cordinat():
#
#     DastinationCordinats = input("enter Dastination Cordinats ")
#     check_dest_input = check_valid(DastinationCordinats)
#     if check_dest_input:
#         DastinationCordinats = DastinationCordinats.split(",")
#         return [int(DastinationCordinats[0]), int(DastinationCordinats[1])]
#     else:
#         answer = input("did ypu want to choos a just a new dest point ? y/o")
#         if answer == "y":
#             destin_Cordinat()
#         else:
#             pass
# chess_bord = BOARD()
# def chess_bord_print():
#     list_bord = []
#     for i in range(8):
#         list_bord = []
#         print("")
#         for x in range(8):
#             if chess_bord._bord[i][x] != 0:
#                 uni = chess_bord._bord[i][x].get_unie()
#                 list_bord.append(uni)
#             else:
#                 list_bord.append("_")
#         for p in range(len(list_bord)):
#             print(list_bord[p], end=" ")
